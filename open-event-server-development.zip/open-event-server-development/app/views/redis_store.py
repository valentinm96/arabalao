from flask_redis import FlaskRedis

redis_store = FlaskRedis()
