def create_app():
    from .instance import app

    return app
