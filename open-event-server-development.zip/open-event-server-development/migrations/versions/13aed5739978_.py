"""empty message

Revision ID: 13aed5739978
Revises: ('34be8a5853bd', '77df37e3e9ad')
Create Date: 2016-06-29 13:19:44.073308

"""

# revision identifiers, used by Alembic.
revision = '13aed5739978'
down_revision = ('34be8a5853bd', '77df37e3e9ad')

from alembic import op
import sqlalchemy as sa
import sqlalchemy_utils


def upgrade():
    pass


def downgrade():
    pass
