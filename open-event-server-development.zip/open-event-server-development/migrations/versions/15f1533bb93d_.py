"""empty message

Revision ID: 15f1533bb93d
Revises: ('d40a49824b53', 'b723e2342f15', 'f07fed8f60e5')
Create Date: 2016-06-17 10:38:33.087948

"""

# revision identifiers, used by Alembic.
revision = '15f1533bb93d'
down_revision = ('d40a49824b53', 'b723e2342f15', 'f07fed8f60e5')

from alembic import op
import sqlalchemy as sa
import sqlalchemy_utils


def upgrade():
    pass


def downgrade():
    pass
