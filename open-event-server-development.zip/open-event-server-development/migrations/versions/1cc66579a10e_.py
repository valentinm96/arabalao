"""empty message

Revision ID: 1cc66579a10e
Revises: ca3156df9a12
Create Date: 2016-08-02 13:20:49.465992

"""

# revision identifiers, used by Alembic.
revision = '1cc66579a10e'
down_revision = 'ca3156df9a12'

def upgrade():
    pass

def downgrade():
    pass
