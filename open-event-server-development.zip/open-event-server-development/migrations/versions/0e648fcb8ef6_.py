"""empty message

Revision ID: 0e648fcb8ef6
Revises: ('265d11072331', '8e7f7864cb60')
Create Date: 2016-06-19 18:14:28.046000

"""

# revision identifiers, used by Alembic.
revision = '0e648fcb8ef6'
down_revision = ('265d11072331', '8e7f7864cb60')

from alembic import op
import sqlalchemy as sa
import sqlalchemy_utils


def upgrade():
    pass


def downgrade():
    pass
