"""empty message

Revision ID: 03d5a2b6ea24
Revises: ('1c7441698fae', 'd7157fcb6e5d')
Create Date: 2016-08-17 21:20:16.058228

"""

# revision identifiers, used by Alembic.
revision = '03d5a2b6ea24'
down_revision = ('1c7441698fae', 'd7157fcb6e5d')

from alembic import op
import sqlalchemy as sa
import sqlalchemy_utils


def upgrade():
    pass


def downgrade():
    pass
